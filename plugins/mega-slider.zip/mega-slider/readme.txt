=== Mega Slider ===
Contributors: ThemeBoy, brianmiyaji
Tags: social sidebar
Requires at least: 3.8
Tested up to: 4.4
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Create custom image sliders.

== Changelog ==

= 1.0 =
* Initial release.
