=== Social Sidebar ===
Contributors: ThemeBoy, brianmiyaji
Tags: social sidebar
Requires at least: 3.8
Tested up to: 4.4
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Add a responsive social media sidebar to your site.

== Changelog ==

= 1.0 =
* Initial release.
