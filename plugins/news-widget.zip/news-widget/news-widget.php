<?php
/*
Plugin Name: News Widget
Plugin URI: http://newswidget.me/
Description: Display latest posts in a widget with single or multiple columns.
Author: ThemeBoy
Author URI: http://themeboy.com
Version: 1.0.1
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'News_Widget' ) ) :

/**
 * Main News_Widget class
 *
 * @class News_Widget
 * @version	1.0.1
 */
class News_Widget {

	/**
	 * Constructor
	 */
	public function __construct() {
		// Define constants
		$this->define_constants();

		// Hooks
		add_action( 'widgets_init', array( $this, 'register_widget' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'styles' ) );
		add_filter( 'http_request_args', array( $this, 'disable_wporg_request' ), 5, 2 );
	}

	/**
	 * Define constants
	*/
	private function define_constants() {
		if ( !defined( 'NEWS_WIDGET_VERSION' ) )
			define( 'NEWS_WIDGET_VERSION', '1.0.1' );

		if ( !defined( 'NEWS_WIDGET_URL' ) )
			define( 'NEWS_WIDGET_URL', plugin_dir_url( __FILE__ ) );

		if ( !defined( 'NEWS_WIDGET_DIR' ) )
			define( 'NEWS_WIDGET_DIR', plugin_dir_path( __FILE__ ) );
	}

	/**
	 * Add widget
	 */
	public function register_widget() {
		include_once( 'includes/class-wp-widget-news-widget.php' );
		register_widget( 'WP_Widget_News_Widget' );
	}

	/**
	 * Enqueue styles
	 */
	public function styles() {
		wp_enqueue_style( 'news-widget-style', trailingslashit( NEWS_WIDGET_URL ) . 'assets/css/news-widget.css', array(), NEWS_WIDGET_VERSION );
	}

	/**
	 * Disable requests to wp.org repository for this plugin.
	 *
	 * @since 1.0.1
	 */
	function disable_wporg_request( $r, $url ) {
		if ( 0 === strpos( $url, 'https://api.wordpress.org/plugins/update-check/1.1/' ) ) {
			$plugins = json_decode( $r['body']['plugins'], true );
			unset( $plugins['plugins'][plugin_basename( __FILE__ )] );
			$r['body']['plugins'] = json_encode( $plugins );
		}
		return $r;
	}
}

endif;

new News_Widget();
